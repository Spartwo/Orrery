using UnityEngine;
using NUnit.Framework;
using System;
using SystemGen;
using Palmmedia.ReportGenerator.Core;
using NUnit.Framework.Internal;

namespace Tests
{
    public class SerialisationTests
    {
        [SetUp]
        public void Setup()
        {

        }

        // =========================
        // Json Serialisation Tests
        // =========================

        [Test]
        public void Test_System_Serialization()
        {
            Assert.NotNull(true);
        }

        [Test]
        public void Test_Settings_Serialization()
        {
            Assert.NotNull(true);
        }

    }
}