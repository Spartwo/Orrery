using UnityEngine;
using NUnit.Framework;
using System;
using SystemGen;
using Palmmedia.ReportGenerator.Core;
using NUnit.Framework.Internal;

namespace Tests
{
    public class PhysicsTests
    {
        [SetUp]
        public void Setup()
        {

        }

        // =========================
        // Orbit 
        // =========================

        [Test]
        public void Test_Orbital_Mechanics()
        {
            Assert.NotNull(true);
        }

        // =========================
        // Confirm Constant Accuracy
        // =========================

    }
}