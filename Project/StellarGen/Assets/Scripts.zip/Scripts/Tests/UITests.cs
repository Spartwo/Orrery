using UnityEngine;
using NUnit.Framework;
using System;
using SystemGen;
using Palmmedia.ReportGenerator.Core;
using NUnit.Framework.Internal;

namespace Tests
{
    public class UITests
    {
        [SetUp]
        public void Setup()
        {

        }

        // =========================
        // Inspector Window Tests
        // =========================

        [Test]
        public void Test_Window_Opens()
        {
            Assert.NotNull(true);
        }

        // =========================
        // Pause Menu Tests
        // =========================

        [Test]
        public void Test_Pause_Functionality()
        {
            Assert.NotNull(true);
        }

    }
}
